import HomeClient from '@/components/home/home-client';

export default function HomePage() {
  return <HomeClient />;
} 