import { LoginClient } from "@/components/admin/login-client";

export default function LoginPage() {
  return <LoginClient />;
} 