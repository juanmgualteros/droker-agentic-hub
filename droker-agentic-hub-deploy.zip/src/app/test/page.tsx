export default function TestPage() {
  return (
    <div className="p-24">
      <h1>Test Page</h1>
      <p>If you can see this, routing is working!</p>
    </div>
  )
} 