"use client"

interface ProductTabsProps {
  productId: string
}

export function ProductTabs({ productId }: ProductTabsProps) {
  return null
} 